const { Sequelize } = require('sequelize');
const path = require('path');

// Create a SQLite database in the project directory
const dbPath = path.join(__dirname, '../database.sqlite');

// Initialize Sequelize with SQLite
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: dbPath,
  logging: console.log // Set to false in production
});

// Test the connection
const testConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
};

// Run the test
testConnection();

module.exports = sequelize;
