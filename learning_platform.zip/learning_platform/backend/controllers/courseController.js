const Course = require('../models/Course');
const Lesson = require('../models/Lesson');

// Get all courses
const getAllCourses = async (req, res) => {
  try {
    const courses = await Course.findAllCourses();
    res.status(200).json(courses);
  } catch (error) {
    console.error('Error fetching courses:', error);
    res.status(500).json({ message: 'Server error fetching courses.' });
  }
};

// Get a single course by ID, including its lessons
const getCourseById = async (req, res) => {
  const { id } = req.params;
  try {
    const course = await Course.findCourseById(id);
    if (!course) {
      return res.status(404).json({ message: 'Course not found.' });
    }
    // Fetch associated lessons
    const lessons = await Lesson.findLessonsByCourseId(id);
    res.status(200).json({ 
      ...course.toJSON(), 
      lessons 
    });
  } catch (error) {
    console.error(`Error fetching course with ID ${id}:`, error);
    res.status(500).json({ message: 'Server error fetching course details.' });
  }
};

// Create a new course
const createCourse = async (req, res) => {
  const { title, description } = req.body;
  // Assuming instructor ID comes from authenticated user (implement later)
  const instructorId = req.user?.userId || 1; // Placeholder - replace with actual auth logic

  if (!title) {
    return res.status(400).json({ message: 'Course title is required.' });
  }

  try {
    const newCourse = await Course.createCourse(title, description, instructorId);
    res.status(201).json(newCourse);
  } catch (error) {
    console.error('Error creating course:', error);
    res.status(500).json({ message: 'Server error creating course.' });
  }
};

module.exports = {
  getAllCourses,
  getCourseById,
  createCourse,
};
