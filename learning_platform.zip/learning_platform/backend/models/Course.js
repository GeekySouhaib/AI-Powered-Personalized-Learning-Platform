const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const User = require('./User');

// Define Course model
const Course = sequelize.define('Course', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  instructor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: User,
      key: 'id'
    }
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

// Define associations
Course.belongsTo(User, { as: 'instructor', foreignKey: 'instructor_id' });

// Class methods
Course.findAllCourses = function() {
  return this.findAll({
    include: [
      {
        model: User,
        as: 'instructor',
        attributes: ['id', 'username']
      }
    ],
    order: [['created_at', 'DESC']]
  });
};

Course.findCourseById = function(id) {
  return this.findByPk(id, {
    include: [
      {
        model: User,
        as: 'instructor',
        attributes: ['id', 'username']
      }
    ]
  });
};

Course.createCourse = function(title, description, instructorId) {
  return this.create({
    title,
    description,
    instructor_id: instructorId
  });
};

module.exports = Course;
