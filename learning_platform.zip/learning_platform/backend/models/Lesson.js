const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const Course = require('./Course');

// Define Lesson model
const Lesson = sequelize.define('Lesson', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  course_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Course,
      key: 'id'
    }
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  video_url: {
    type: DataTypes.STRING,
    allowNull: true
  },
  lesson_order: {
    type: DataTypes.INTEGER,
    allowNull: true
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

// Define associations
Lesson.belongsTo(Course, { foreignKey: 'course_id' });
Course.hasMany(Lesson, { foreignKey: 'course_id' });

// Class methods
Lesson.findLessonsByCourseId = function(courseId) {
  return this.findAll({
    where: { course_id: courseId },
    order: [
      ['lesson_order', 'ASC'],
      ['created_at', 'ASC']
    ]
  });
};

Lesson.findLessonById = function(id) {
  return this.findByPk(id);
};

Lesson.createLesson = function(courseId, title, content, videoUrl, order) {
  return this.create({
    course_id: courseId,
    title,
    content,
    video_url: videoUrl,
    lesson_order: order
  });
};

module.exports = Lesson;
