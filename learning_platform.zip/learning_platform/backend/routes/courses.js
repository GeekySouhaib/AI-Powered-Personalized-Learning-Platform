const express = require("express");
const {
  getAllCourses,
  getCourseById,
  createCourse,
} = require("../controllers/courseController");
// Add lesson controller import if needed for lesson-specific routes under /courses/:courseId/lessons
// const { createLesson, getLessonsForCourse } = require("../controllers/lessonController");

// Middleware for authentication (placeholder - implement properly later)
const authenticateToken = (req, res, next) => {
  // Example: Get token from header, verify it, attach user to req
  // For now, let's mock a user ID for course creation
  // In a real app, this would involve verifying a JWT
  console.log("Auth middleware called (mocked)");
  // req.user = { userId: 1 }; // Mock user ID 1
  next();
};

const router = express.Router();

// GET /api/courses - Get all courses (public)
router.get("/", getAllCourses);

// GET /api/courses/:id - Get a single course by ID (public)
router.get("/:id", getCourseById);

// POST /api/courses - Create a new course (protected)
// Apply authentication middleware here when ready
router.post("/", authenticateToken, createCourse);

// --- Lesson Routes (nested under courses) ---
// Example: POST /api/courses/:courseId/lessons - Create a lesson for a course (protected)
// router.post("/:courseId/lessons", authenticateToken, createLesson);

// Example: GET /api/courses/:courseId/lessons - Get all lessons for a course (public or protected)
// router.get("/:courseId/lessons", getLessonsForCourse);

// Add update and delete routes for courses and lessons as needed

module.exports = router;

