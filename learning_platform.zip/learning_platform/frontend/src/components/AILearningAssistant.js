import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, TextField, Button, CircularProgress, Divider } from '@mui/material';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import PersonIcon from '@mui/icons-material/Person';

const AILearningAssistant = ({ courseId, lessonId, userProgress }) => {
  const [loading, setLoading] = useState(false);
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState([
    {
      role: 'assistant',
      content: 'Hello! I\'m your AI learning assistant. I can help answer questions about this lesson, provide additional explanations, or suggest related resources. How can I help you today?'
    }
  ]);

  // This would be replaced with actual AI integration in the future
  const simulateAIResponse = (userQuestion) => {
    setLoading(true);
    
    // Simulate network delay
    setTimeout(() => {
      let response;
      
      // Simple keyword-based responses for demonstration
      if (userQuestion.toLowerCase().includes('explain') || userQuestion.toLowerCase().includes('what is')) {
        response = "Great question! This concept refers to a fundamental principle in this field. It's important because it forms the foundation for more advanced topics we'll cover later. Would you like me to provide some examples to make it clearer?";
      } else if (userQuestion.toLowerCase().includes('example') || userQuestion.toLowerCase().includes('show me')) {
        response = "Here's an example that might help illustrate this concept: [Example details would be provided here]. Does this help clarify things? I can provide more examples if needed.";
      } else if (userQuestion.toLowerCase().includes('resource') || userQuestion.toLowerCase().includes('learn more')) {
        response = "I'd recommend checking out these additional resources: 1) The 'Advanced Topics' section in Chapter 3 of the course materials, 2) This interactive tutorial: [URL would be here], 3) The practice exercises in the supplementary materials section.";
      } else if (userQuestion.toLowerCase().includes('stuck') || userQuestion.toLowerCase().includes('confused') || userQuestion.toLowerCase().includes('don\'t understand')) {
        response = "I understand this can be challenging. Let's break it down into smaller parts: 1) First, consider the basic principle we covered earlier, 2) Then, think about how it applies in this specific context, 3) Finally, try working through the example step by step. Which part specifically is giving you trouble?";
      } else {
        response = "That's an interesting question. Based on what we've covered in this lesson, I'd say the key points to consider are: 1) The fundamental principles we discussed, 2) How these concepts apply in real-world scenarios, and 3) The relationship between this topic and other areas we've studied. Would you like me to elaborate on any of these aspects?";
      }
      
      setConversation(prev => [
        ...prev,
        { role: 'user', content: userQuestion },
        { role: 'assistant', content: response }
      ]);
      
      setLoading(false);
      setQuestion('');
    }, 1500);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!question.trim()) return;
    
    simulateAIResponse(question);
  };

  return (
    <Paper elevation={2} sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <SmartToyIcon sx={{ mr: 1 }} />
        AI Learning Assistant
      </Typography>
      <Divider sx={{ mb: 2 }} />
      
      <Box sx={{ 
        flexGrow: 1, 
        mb: 2, 
        overflow: 'auto', 
        maxHeight: '400px',
        bgcolor: 'background.default',
        p: 2,
        borderRadius: 1
      }}>
        {conversation.map((message, index) => (
          <Box 
            key={index} 
            sx={{ 
              display: 'flex', 
              mb: 2,
              flexDirection: message.role === 'user' ? 'row-reverse' : 'row'
            }}
          >
            <Box 
              sx={{ 
                bgcolor: message.role === 'user' ? 'primary.main' : 'grey.200',
                color: message.role === 'user' ? 'white' : 'text.primary',
                p: 2,
                borderRadius: 2,
                maxWidth: '80%'
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                {message.role === 'user' ? (
                  <PersonIcon fontSize="small" sx={{ mr: 0.5 }} />
                ) : (
                  <SmartToyIcon fontSize="small" sx={{ mr: 0.5 }} />
                )}
                <Typography variant="caption" fontWeight="bold">
                  {message.role === 'user' ? 'You' : 'AI Assistant'}
                </Typography>
              </Box>
              <Typography variant="body2">{message.content}</Typography>
            </Box>
          </Box>
        ))}
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'flex-start', mb: 2 }}>
            <Box sx={{ bgcolor: 'grey.200', p: 2, borderRadius: 2 }}>
              <CircularProgress size={20} thickness={5} />
            </Box>
          </Box>
        )}
      </Box>
      
      <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex' }}>
        <TextField
          fullWidth
          placeholder="Ask a question about this lesson..."
          variant="outlined"
          size="small"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          disabled={loading}
        />
        <Button 
          type="submit" 
          variant="contained" 
          sx={{ ml: 1 }}
          disabled={loading || !question.trim()}
        >
          Send
        </Button>
      </Box>
    </Paper>
  );
};

export default AILearningAssistant;
