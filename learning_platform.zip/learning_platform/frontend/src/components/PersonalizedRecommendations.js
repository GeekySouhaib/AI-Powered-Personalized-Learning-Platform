import React, { useEffect } from 'react';
import { Box, Typography, Paper, Divider, List, ListItem, ListItemIcon, ListItemText, Chip } from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import BookmarkIcon from '@mui/icons-material/Bookmark';

const PersonalizedRecommendations = ({ userId, courseId, learningHistory }) => {
  // This would be replaced with actual AI-based recommendations in the future
  const recommendations = [
    {
      type: 'course',
      title: 'Advanced Data Structures',
      reason: 'Based on your interest in algorithms',
      id: 2
    },
    {
      type: 'resource',
      title: 'Interactive Python Tutorial',
      reason: 'Complements your current learning path',
      url: 'https://example.com/python-tutorial'
    },
    {
      type: 'concept',
      title: 'Review: Big O Notation',
      reason: 'Foundation for upcoming lessons',
      id: 'big-o-notation'
    }
  ];

  // Simulate analyzing user behavior
  useEffect(() => {
    console.log('Analyzing user learning patterns for personalized recommendations');
    // In a real implementation, this would call an AI service to generate recommendations
  }, [userId, courseId, learningHistory]);

  return (
    <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
      <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <LightbulbIcon sx={{ mr: 1 }} />
        Personalized Recommendations
      </Typography>
      <Divider sx={{ mb: 2 }} />
      
      <List disablePadding>
        {recommendations.map((item, index) => (
          <ListItem 
            key={index}
            sx={{ 
              mb: 1.5, 
              p: 1.5, 
              borderRadius: 1,
              bgcolor: 'background.default',
              '&:hover': {
                bgcolor: 'action.hover'
              }
            }}
          >
            <ListItemIcon sx={{ minWidth: 40 }}>
              {item.type === 'course' && <TrendingUpIcon color="primary" />}
              {item.type === 'resource' && <BookmarkIcon color="secondary" />}
              {item.type === 'concept' && <LightbulbIcon color="warning" />}
            </ListItemIcon>
            <ListItemText 
              primary={item.title}
              secondary={
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                  <Typography variant="caption" color="text.secondary" sx={{ mr: 1 }}>
                    {item.reason}
                  </Typography>
                  <Chip 
                    label={item.type} 
                    size="small" 
                    variant="outlined"
                    color={
                      item.type === 'course' ? 'primary' : 
                      item.type === 'resource' ? 'secondary' : 'default'
                    }
                    sx={{ height: 20, '& .MuiChip-label': { px: 1, py: 0 } }}
                  />
                </Box>
              }
            />
          </ListItem>
        ))}
      </List>
      
      <Box sx={{ mt: 2, pt: 2, borderTop: '1px dashed', borderColor: 'divider' }}>
        <Typography variant="body2" color="text.secondary">
          These recommendations are personalized based on your learning patterns and progress. They'll become more accurate as you continue learning.
        </Typography>
      </Box>
    </Paper>
  );
};

export default PersonalizedRecommendations;
