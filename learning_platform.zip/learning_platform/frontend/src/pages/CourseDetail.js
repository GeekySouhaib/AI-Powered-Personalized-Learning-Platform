import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  Container,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  Button,
  CircularProgress,
  Alert,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  Chip
} from '@mui/material';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import DescriptionIcon from '@mui/icons-material/Description';
import PersonIcon from '@mui/icons-material/Person';
import DateRangeIcon from '@mui/icons-material/DateRange';
import MainLayout from '../components/MainLayout';

const CourseDetail = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchCourseDetails = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`http://localhost:5000/api/courses/${courseId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        setCourse(response.data);
        setLessons(response.data.lessons || []);
      } catch (err) {
        console.error('Error fetching course details:', err);
        setError('Failed to load course details. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchCourseDetails();
  }, [courseId]);

  const handleStartLesson = (lessonId) => {
    navigate(`/courses/${courseId}/lessons/${lessonId}`);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Unknown date';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <MainLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Alert severity="error" sx={{ mb: 4 }}>
            {error}
          </Alert>
        ) : course ? (
          <>
            <Box sx={{ mb: 4 }}>
              <Typography variant="h4" component="h1" gutterBottom>
                {course.title}
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <PersonIcon fontSize="small" sx={{ mr: 0.5 }} />
                  <Typography variant="body2">
                    Instructor: {course.instructor_username || 'Unknown'}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <DateRangeIcon fontSize="small" sx={{ mr: 0.5 }} />
                  <Typography variant="body2">
                    Created: {formatDate(course.created_at)}
                  </Typography>
                </Box>
                <Chip 
                  label="Programming" 
                  size="small" 
                  color="primary" 
                  variant="outlined"
                />
              </Box>
            </Box>

            <Grid container spacing={4}>
              <Grid item xs={12} md={8}>
                <Paper elevation={2} sx={{ p: 3, mb: 4 }}>
                  <Typography variant="h6" gutterBottom>
                    About this course
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Typography variant="body1" paragraph>
                    {course.description || 'No description available for this course.'}
                  </Typography>
                  
                  <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
                    What you'll learn
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <List dense>
                        <ListItem>
                          <ListItemIcon sx={{ minWidth: 36 }}>•</ListItemIcon>
                          <ListItemText primary="Core concepts and fundamentals" />
                        </ListItem>
                        <ListItem>
                          <ListItemIcon sx={{ minWidth: 36 }}>•</ListItemIcon>
                          <ListItemText primary="Practical applications" />
                        </ListItem>
                      </List>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <List dense>
                        <ListItem>
                          <ListItemIcon sx={{ minWidth: 36 }}>•</ListItemIcon>
                          <ListItemText primary="Advanced techniques" />
                        </ListItem>
                        <ListItem>
                          <ListItemIcon sx={{ minWidth: 36 }}>•</ListItemIcon>
                          <ListItemText primary="Real-world problem solving" />
                        </ListItem>
                      </List>
                    </Grid>
                  </Grid>
                </Paper>

                <Paper elevation={2} sx={{ p: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Course Content
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  
                  {lessons.length > 0 ? (
                    <List>
                      {lessons.map((lesson, index) => (
                        <ListItem 
                          key={lesson.id}
                          sx={{ 
                            mb: 1, 
                            border: '1px solid',
                            borderColor: 'divider',
                            borderRadius: 1,
                            '&:hover': {
                              backgroundColor: 'action.hover'
                            }
                          }}
                        >
                          <ListItemIcon>
                            {lesson.video_url ? (
                              <PlayCircleOutlineIcon color="primary" />
                            ) : (
                              <DescriptionIcon color="primary" />
                            )}
                          </ListItemIcon>
                          <ListItemText 
                            primary={`${index + 1}. ${lesson.title}`}
                            secondary={lesson.content ? `${lesson.content.substring(0, 60)}...` : 'No description'}
                          />
                          <Button 
                            variant="outlined" 
                            size="small"
                            onClick={() => handleStartLesson(lesson.id)}
                          >
                            Start
                          </Button>
                        </ListItem>
                      ))}
                    </List>
                  ) : (
                    <Typography variant="body1" color="text.secondary" sx={{ py: 2 }}>
                      No lessons available for this course yet.
                    </Typography>
                  )}
                </Paper>
              </Grid>

              <Grid item xs={12} md={4}>
                <Card sx={{ position: 'sticky', top: 20 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Course Overview
                    </Typography>
                    <Divider sx={{ mb: 2 }} />
                    
                    <Box sx={{ mb: 2 }}>
                      <Typography variant="body2" color="text.secondary">
                        Total Lessons
                      </Typography>
                      <Typography variant="h5">
                        {lessons.length}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mb: 2 }}>
                      <Typography variant="body2" color="text.secondary">
                        Estimated Duration
                      </Typography>
                      <Typography variant="h5">
                        {lessons.length * 15} minutes
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="body2" color="text.secondary">
                        Difficulty Level
                      </Typography>
                      <Typography variant="h5">
                        Beginner
                      </Typography>
                    </Box>
                    
                    <Button 
                      variant="contained" 
                      fullWidth
                      size="large"
                      onClick={() => lessons.length > 0 && handleStartLesson(lessons[0].id)}
                      disabled={lessons.length === 0}
                    >
                      {lessons.length > 0 ? 'Start Learning' : 'No Lessons Available'}
                    </Button>
                    
                    <Box sx={{ mt: 3 }}>
                      <Typography variant="body2" color="text.secondary" paragraph>
                        This course includes:
                      </Typography>
                      <List dense disablePadding>
                        <ListItem disablePadding sx={{ pb: 1 }}>
                          <ListItemIcon sx={{ minWidth: 36 }}>
                            <PlayCircleOutlineIcon fontSize="small" />
                          </ListItemIcon>
                          <ListItemText primary="On-demand video lessons" />
                        </ListItem>
                        <ListItem disablePadding sx={{ pb: 1 }}>
                          <ListItemIcon sx={{ minWidth: 36 }}>
                            <DescriptionIcon fontSize="small" />
                          </ListItemIcon>
                          <ListItemText primary="Comprehensive text materials" />
                        </ListItem>
                      </List>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        ) : (
          <Alert severity="warning">
            Course not found. The course may have been removed or you don't have access.
          </Alert>
        )}
      </Container>
    </MainLayout>
  );
};

export default CourseDetail;
