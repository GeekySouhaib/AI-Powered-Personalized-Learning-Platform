import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  Container,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  CircularProgress,
  Alert,
  Paper,
  Divider
} from '@mui/material';
import SchoolIcon from '@mui/icons-material/School';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import PersonIcon from '@mui/icons-material/Person';
import MainLayout from '../components/MainLayout';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Get user from localStorage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    // Fetch enrolled courses or recommended courses
    const fetchCourses = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/api/courses', {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        // For now, just show all courses. In the future, this could be personalized
        setCourses(response.data.slice(0, 4)); // Limit to 4 courses for the dashboard
      } catch (err) {
        console.error('Error fetching courses:', err);
        setError('Failed to load your courses. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  const handleViewAllCourses = () => {
    navigate('/courses');
  };

  const handleViewCourse = (courseId) => {
    navigate(`/courses/${courseId}`);
  };

  return (
    <MainLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom>
            Welcome back, {user?.username || 'Learner'}!
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            Continue your learning journey with personalized recommendations.
          </Typography>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 4 }}>
            {error}
          </Alert>
        )}

        <Grid container spacing={4}>
          {/* Learning Stats */}
          <Grid item xs={12} md={4}>
            <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
              <Typography variant="h6" gutterBottom>
                Your Learning Stats
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <SchoolIcon color="primary" sx={{ mr: 1 }} />
                <Typography>
                  Courses Enrolled: <strong>{courses.length || 0}</strong>
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AutoStoriesIcon color="primary" sx={{ mr: 1 }} />
                <Typography>
                  Lessons Completed: <strong>0</strong>
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <PersonIcon color="primary" sx={{ mr: 1 }} />
                <Typography>
                  Learning Streak: <strong>1 day</strong>
                </Typography>
              </Box>
            </Paper>
          </Grid>

          {/* Recommended Courses */}
          <Grid item xs={12} md={8}>
            <Paper elevation={2} sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Recommended for You
                </Typography>
                <Button 
                  variant="outlined" 
                  size="small"
                  onClick={handleViewAllCourses}
                >
                  View All Courses
                </Button>
              </Box>
              <Divider sx={{ mb: 2 }} />
              
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                  <CircularProgress />
                </Box>
              ) : courses.length > 0 ? (
                <Grid container spacing={2}>
                  {courses.map((course) => (
                    <Grid item xs={12} sm={6} key={course.id}>
                      <Card 
                        sx={{ 
                          height: '100%', 
                          display: 'flex', 
                          flexDirection: 'column',
                          transition: 'transform 0.2s',
                          '&:hover': {
                            transform: 'translateY(-5px)',
                            boxShadow: 4
                          }
                        }}
                      >
                        <CardMedia
                          component="img"
                          height="140"
                          image={`https://source.unsplash.com/random/300x200?education,${course.id}`}
                          alt={course.title}
                        />
                        <CardContent sx={{ flexGrow: 1 }}>
                          <Typography gutterBottom variant="h6" component="div">
                            {course.title}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {course.description?.substring(0, 100) || 'No description available'}
                            {course.description?.length > 100 ? '...' : ''}
                          </Typography>
                        </CardContent>
                        <Box sx={{ p: 2, pt: 0 }}>
                          <Button 
                            size="small" 
                            variant="contained"
                            onClick={() => handleViewCourse(course.id)}
                            fullWidth
                          >
                            View Course
                          </Button>
                        </Box>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              ) : (
                <Box sx={{ p: 2, textAlign: 'center' }}>
                  <Typography variant="body1">
                    No courses available yet. Check back soon!
                  </Typography>
                  <Button 
                    variant="contained" 
                    sx={{ mt: 2 }}
                    onClick={handleViewAllCourses}
                  >
                    Browse All Courses
                  </Button>
                </Box>
              )}
            </Paper>
          </Grid>

          {/* AI Learning Assistant Placeholder */}
          <Grid item xs={12}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                mt: 2, 
                backgroundColor: 'primary.light', 
                color: 'primary.contrastText' 
              }}
            >
              <Typography variant="h6" gutterBottom>
                AI Learning Assistant
              </Typography>
              <Typography variant="body1" paragraph>
                Our AI assistant can help personalize your learning experience based on your progress and preferences.
              </Typography>
              <Button 
                variant="contained" 
                color="secondary"
                disabled
              >
                Coming Soon
              </Button>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
};

export default Dashboard;
