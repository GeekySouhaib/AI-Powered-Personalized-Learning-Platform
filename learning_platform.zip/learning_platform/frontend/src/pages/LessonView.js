import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  Container,
  Typography,
  Box,
  Paper,
  CircularProgress,
  Alert,
  Button,
  Divider,
  Card,
  CardContent,
  Grid,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import MainLayout from '../components/MainLayout';

const LessonView = () => {
  const { courseId, lessonId } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [lesson, setLesson] = useState(null);
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        
        // Fetch course details including all lessons
        const courseResponse = await axios.get(`http://localhost:5000/api/courses/${courseId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        setCourse(courseResponse.data);
        setLessons(courseResponse.data.lessons || []);
        
        // Find the current lesson from the lessons array
        const currentLesson = courseResponse.data.lessons?.find(l => l.id === parseInt(lessonId));
        if (currentLesson) {
          setLesson(currentLesson);
        } else {
          setError('Lesson not found in this course.');
        }
      } catch (err) {
        console.error('Error fetching lesson data:', err);
        setError('Failed to load lesson. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [courseId, lessonId]);

  const handleNavigateToLesson = (id) => {
    navigate(`/courses/${courseId}/lessons/${id}`);
  };

  const handleBackToCourse = () => {
    navigate(`/courses/${courseId}`);
  };

  const findNextLesson = () => {
    if (!lessons.length) return null;
    
    const currentIndex = lessons.findIndex(l => l.id === parseInt(lessonId));
    if (currentIndex === -1 || currentIndex === lessons.length - 1) return null;
    
    return lessons[currentIndex + 1];
  };

  const nextLesson = findNextLesson();

  return (
    <MainLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={handleBackToCourse}
          sx={{ mb: 2 }}
        >
          Back to Course
        </Button>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Alert severity="error" sx={{ mb: 4 }}>
            {error}
          </Alert>
        ) : lesson ? (
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Paper elevation={2} sx={{ p: 3, mb: 3 }}>
                <Typography variant="h5" component="h1" gutterBottom>
                  {lesson.title}
                </Typography>
                <Divider sx={{ mb: 3 }} />
                
                {lesson.video_url && (
                  <Box sx={{ mb: 3, position: 'relative', paddingTop: '56.25%', backgroundColor: '#000' }}>
                    <Box
                      sx={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Typography variant="body1" color="white">
                        Video player placeholder - {lesson.video_url}
                      </Typography>
                      <PlayCircleOutlineIcon sx={{ fontSize: 60, color: 'white', position: 'absolute' }} />
                    </Box>
                  </Box>
                )}
                
                <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}>
                  {lesson.content || 'No content available for this lesson.'}
                </Typography>
                
                {/* Placeholder for AI-powered personalized content */}
                <Paper 
                  elevation={0} 
                  sx={{ 
                    p: 2, 
                    mt: 4, 
                    backgroundColor: 'primary.light', 
                    color: 'primary.contrastText',
                    borderRadius: 2
                  }}
                >
                  <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                    AI-Powered Learning Insights
                  </Typography>
                  <Typography variant="body2">
                    This section will provide personalized insights and additional resources based on your learning progress and preferences.
                  </Typography>
                </Paper>
                
                <Box sx={{ mt: 4, display: 'flex', justifyContent: 'space-between' }}>
                  <Button
                    variant="outlined"
                    onClick={handleBackToCourse}
                  >
                    Back to Course
                  </Button>
                  
                  {nextLesson && (
                    <Button
                      variant="contained"
                      onClick={() => handleNavigateToLesson(nextLesson.id)}
                    >
                      Next Lesson
                    </Button>
                  )}
                </Box>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ mb: 3 }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Course Progress
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box sx={{ position: 'relative', display: 'inline-flex', mr: 2 }}>
                      <CircularProgress variant="determinate" value={10} />
                      <Box
                        sx={{
                          top: 0,
                          left: 0,
                          bottom: 0,
                          right: 0,
                          position: 'absolute',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Typography variant="caption" component="div" color="text.secondary">
                          10%
                        </Typography>
                      </Box>
                    </Box>
                    <Typography variant="body2">
                      1 of {lessons.length} lessons completed
                    </Typography>
                  </Box>
                  <Button 
                    variant="outlined" 
                    size="small" 
                    startIcon={<BookmarkIcon />}
                    fullWidth
                  >
                    Mark as Completed
                  </Button>
                </CardContent>
              </Card>
              
              <Paper elevation={2} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Course Content
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <List dense disablePadding>
                  {lessons.map((l, index) => (
                    <ListItem 
                      key={l.id}
                      button
                      selected={l.id === parseInt(lessonId)}
                      onClick={() => handleNavigateToLesson(l.id)}
                      sx={{ 
                        borderRadius: 1,
                        mb: 0.5,
                        backgroundColor: l.id === parseInt(lessonId) ? 'action.selected' : 'transparent'
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        {l.id === parseInt(lessonId) ? (
                          <PlayCircleOutlineIcon color="primary" fontSize="small" />
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            {index + 1}
                          </Typography>
                        )}
                      </ListItemIcon>
                      <ListItemText 
                        primary={l.title}
                        primaryTypographyProps={{
                          variant: 'body2',
                          color: l.id === parseInt(lessonId) ? 'primary' : 'textPrimary'
                        }}
                      />
                      {false && ( // Placeholder for completed status
                        <CheckCircleIcon color="success" fontSize="small" />
                      )}
                    </ListItem>
                  ))}
                </List>
              </Paper>
            </Grid>
          </Grid>
        ) : (
          <Alert severity="warning">
            Lesson not found. It may have been removed or you don't have access.
          </Alert>
        )}
      </Container>
    </MainLayout>
  );
};

export default LessonView;
